<?php
// Get the requested path
$request_path = $_GET['request_path'] ?? '';

// Route to the appropriate service
switch ($request_path) {
    case 'users':
        include 'services/service_users.php';
        break;
    case 'products':
        include 'services/service_products.php';
        break;
    default:
        http_response_code(404);
        echo json_encode(["error" => "Endpoint not found"]);
        exit;
}

// Hardcoded valid API keys
$valid_api_keys = [
    'key123' => 'UserA',
    'key456' => 'UserB'
];

// Get API key from headers
$headers = getallheaders();
$api_key = $headers['X-API-Key'] ?? '';

// Validate API key
if (!isset($valid_api_keys[$api_key])) {
    http_response_code(401);
    echo json_encode(["error" => "Invalid or missing API Key"]);
    exit;
}

$rate_limit_dir = 'ratelimit_data/';
$rate_limit_file = $rate_limit_dir . $api_key . '.json';
$current_time = time();
$limit = 10; // 10 requests per minute

// Read existing data
if (file_exists($rate_limit_file)) {
    $data = json_decode(file_get_contents($rate_limit_file), true);
    $time_diff = $current_time - $data['timestamp'];
    if ($time_diff > 60) {
        // Reset counter
        $data = ['timestamp' => $current_time, 'count' => 1];
    } else {
        if ($data['count'] >= $limit) {
            http_response_code(429);
            echo json_encode(["error" => "Rate limit exceeded"]);
            exit;
        }
        $data['count']++;
    }
} else {
    $data = ['timestamp' => $current_time, 'count' => 1];
}

// Save updated data
file_put_contents($rate_limit_file, json_encode($data));

$log_message = sprintf(
    "[%s] - IP: %s - API Key: %s - Path: %s - Status: %d\n",
    date('Y-m-d H:i:s'),
    $_SERVER['REMOTE_ADDR'],
    $api_key ?: 'None/Invalid',
    $request_path,
    http_response_code()
);
file_put_contents('logs/gateway.log', $log_message, FILE_APPEND);
